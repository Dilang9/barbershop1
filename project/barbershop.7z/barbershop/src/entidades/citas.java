package entidades;


public class citas {      
    
    private int id;
    private int tipo;
    private int fecha;
    private int id_clientes;
    private int id_servicio;
    private boolean activo;
    private String nombre;

    public citas(int id, int tipo, int fecha, int id_clientes, int id_servicio, boolean activo) {
        this.id = id;
        this.tipo = tipo;
        this.fecha = fecha;
        this.id_clientes = id_clientes;
        this.id_servicio = id_servicio;
        this.activo = activo;
    }

    public int getId() {
        return id;
    }

    public int getTipo() {
        return tipo;
    }

    public int getFecha() {
        return fecha;
    }

    public int getId_clientes() {
        return id_clientes;
    }

    public int getId_servicio() {
        return id_servicio;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public void setFecha(int fecha) {
        this.fecha = fecha;
    }

    public void setId_clientes(int id_clientes) {
        this.id_clientes = id_clientes;
    }

    public void setId_servicio(int id_servicio) {
        this.id_servicio = id_servicio;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public citas() {
    }

    @Override
    public String toString() {
        return "citas{" + "id=" + id + ", tipo=" + tipo + ", fecha=" + fecha + ", id_clientes=" + id_clientes + ", id_servicio=" + id_servicio + ", activo=" + activo + '}';
    }
    
    

    
    
    
    
    
   
    
    
    
    
}
