
package Crud;
import java.util.List;

public class crud {
    
   public interface Crud<citas> {
   public List<citas> listar(String texto);
   public boolean insertar(citas obj);
   public boolean actualizar(citas obj);
   public boolean desactivar(int id);
   public boolean activar(int id);
   public int total();
   public boolean existe(String texto);
}
    
}
