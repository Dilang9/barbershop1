package Datos;

import Crud.crud;
import Database.conexion;
import entidades.citas;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class CitasDAO extends crud<citas> {

    private final conexion CON;
    private PreparedStatement ps;
    private ResultSet rs;
    private boolean resp;

    public CitasDAO() {
        CON = conexion.getInstancia();
    }

    
    public boolean insertar(citas obj) {
        resp = false;
        try {
            ps = CON.conectar().prepareStatement("INSERT INTO citas (nombre) VALUES (?)");
            ps.setString(1, obj.getNombre()); // ← ¡IMPORTANTE! Asignar el valor al parámetro
            if (ps.executeUpdate() > 0) {
                resp = true;
            }
            ps.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally {
            ps = null;
            CON.desconectar();
        }
        return resp;
    }
}
