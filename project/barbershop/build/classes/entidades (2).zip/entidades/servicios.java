package entidades;


public class servicios {      
    
    private int id;
    private String nombre;
    private int precio;
    private int id_clientes;
    private boolean activo;

    public servicios(int id, String nombre, int precio, int id_clientes, boolean activo) {//se invocan los atributos de la tabla
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.id_clientes = id_clientes;
        this.activo = activo;
       
    }
//se captura los get y los set
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getPrecio() {
        return precio;
    }

    public int getId_clientes() {
        return id_clientes;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public void setId_clientes(int id_clientes) {
        this.id_clientes = id_clientes;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
    
    
//sirve pára verificar que se ingresa a la base de datos
    @Override
    public String toString() {
        return "servicios{" + "id=" + id + ", nombre=" + nombre + ", precio=" + precio + ", id_clientes=" + id_clientes + ", activo=" + activo + '}';
    }
    
    
    
    
   
    
    
    
    
}
